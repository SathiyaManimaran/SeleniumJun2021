package week3.day2;

public interface CIBIL extends RBI{
	
	void creditScore();
	
	

}
