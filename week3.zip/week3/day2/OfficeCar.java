package week3.day2;

import week3.day1.Vehicle;

public class OfficeCar extends Vehicle {
	
	public static void main(String[] args) {
		
		OfficeCar oc = new OfficeCar();
		oc.applyBrake();
	
	}

}
