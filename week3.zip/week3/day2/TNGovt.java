package week3.day2;

public class TNGovt extends FinanceMinistry {

	public void covidTreatment() {
		System.out.println("5000");

	}

	public static void main(String[] args) {
		TNGovt tng = new TNGovt();
				
	    tng.covidTreatment();
		tng.disaterLoan();
	}

}
