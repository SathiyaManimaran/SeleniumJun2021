package week3.day2;

public class MyBank {
	
	public static void main(String[] args) {
		//InterfaceName referenceName = new ClassName()
		RBI bank = new PNB();
		//PNB bank = new PNB();
		
		bank.savingsAccount();
		bank.fixedDeposit();
		//bank.eduLoan();
		
		
		/*
		 * bank1.savingsAccount(); bank1.fixedDeposit(); bank1.agriLoan();
		 */
		
		
		
		
	}

}
