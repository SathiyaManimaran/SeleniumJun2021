package week3.day2;

public abstract class FinanceMinistry {
	
	public abstract void covidTreatment();
	
	public void disaterLoan() {
		System.out.println("50000");
	}

}
