package week3.day1;

/*length() -> to find the number of characters in the string
 * equals() -> to compare 2 string values (Case sensitive)
 * equalsIgnoreCase() -> to compare 2 string values (ignoring Case sensitive)
 * charAt() -> to get single character from string
 * toCharArray() -> to convert the string into char[]
 * concat() -> to concatenate 2 strings
 * contains() -> to check the value of one string part of another string
 * toUpperCase() -> to covert into upper case
 * toLowerCase() -> to convert into lower case
 * replace() -> to change one character into another character
 * replaceAll() -> to change the characters using regex
 * split() -> to split a string into multiple string using regex
 * 
 * 
*/

public class LearnMoreStringMethods {

	public static void main(String[] args) {
		/*
		 * String input = "Welcome Home 12334242";
		 * 
		 * String[] split = input.split("e");
		 * 
		 * System.out.println(split[1]);
		 */
		
		//System.out.println(input.replaceAll("[0-9]", ""));
		
		/*
		 * int lengthOfInput = input.length();
		 * 
		 * String newInput = input.replace("e", "");
		 * 
		 * int lengthAfterRemovingE = newInput.length();
		 * 
		 * System.out.println(lengthOfInput - lengthAfterRemovingE);
		 */
		
		//Welcome -> Become
		//System.out.println(input.replace("Wel", "Be"));
		
		//System.out.println(input.replace('e', 'x'));
		
		
		
		
		
		
		
		
		//String newInput = "come";
		
		
		//System.out.println(input.toUpperCase());
		//System.out.println(input.toLowerCase());
		
		//System.out.println(input.contains(newInput));
		
		//System.out.println(input.concat(newInput));
		
		//System.out.println(input+newInput);
		
		/*
		 * char[] ch = input.toCharArray();
		 * 
		 * for (int i = 0; i < ch.length; i++) {
		 * 
		 * System.out.println(ch[i]);
		 * 
		 * }
		 */
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
