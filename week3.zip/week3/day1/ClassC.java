package week3.day1;

public class ClassC extends ClassA{
	
	public static void main(String[] args) {
		ClassC c = new ClassC();
		
		c.m3();
	}

}
