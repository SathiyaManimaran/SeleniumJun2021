package week3.day1;

public class BMW extends Car {
	
	public void airBag() {
		System.out.println("air bag");

	}
	
	public static void main(String[] args) {
		BMW bmw = new BMW();
		
		bmw.airBag(); // BMW class
		
		bmw.airCondition(); // Car class
		
		bmw.applyBrake();
		bmw.soundHorn(); //Vehicle class
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	

}
