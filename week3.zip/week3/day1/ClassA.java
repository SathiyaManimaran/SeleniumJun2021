package week3.day1;

public class ClassA {
	
	public void m3() {
		System.out.println("m3 in ClassA");
	}

}
