package week3.day1;

class NewOwnCar {
	
	public void autoWiper() {
		System.out.println("Wiper");

	}

}
