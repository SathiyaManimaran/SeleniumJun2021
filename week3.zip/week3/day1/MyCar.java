package week3.day1;

public class MyCar {
	
	public static void main(String[] args) {
		
		Vehicle veh = new Vehicle();
		veh.applyBrake();
		
		/*
		 * BMW myBmw = new BMW();
		 * 
		 * myBmw.applyBrake(); myBmw.soundHorn();
		 * 
		 * myBmw.airCondition(); myBmw.airBag();
		 */
		
		
		
		/*
		 * Vehicle veh = new Vehicle(); veh.applyBrake(); veh.soundHorn();
		 */
		
		
		
		/*
		 * Car newCar = new Car();
		 * 
		 * newCar.airCondition(); newCar.applyBrake(); newCar.soundHorn();
		 */
		
		/*
		 * Vehicle veh = new Vehicle(); veh.applyBrake(); veh.soundHorn();
		 * 
		 * 
		 * Car newCar = new Car(); newCar.airCondition();
		 */
		
		
	}

}
