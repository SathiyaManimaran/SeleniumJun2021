package week3.day1;

public class SBIHO {
	
	public void fixedDeposit() {
		System.out.println("6%");

	}
	
	public static void main(String[] args) {
		
	}

}
