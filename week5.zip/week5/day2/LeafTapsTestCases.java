package week5.day2;

import org.testng.annotations.Test;

public class LeafTapsTestCases {

	@Test
	public void createLead() {
		System.out.println("create lead");
	//	throw new RuntimeException();

	}
	
	
	
	/*
	 * @Test(priority = 2, dependsOnMethods = {"createLead", "editLead"}) public
	 * void deleteLead() { System.out.println("delete lead");
	 * 
	 * }
	 */
}
