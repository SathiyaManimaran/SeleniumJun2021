package week5.day1;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class Module2TestCases extends ProjectCommonMethods{
	
  @Test
  public void test2() {
	  System.out.println("test2");

  }
  
	/*
	 * @BeforeMethod public void beforeMethod() {
	 * System.out.println("beforeMethod - Module2"); }
	 * 
	 * @AfterMethod public void afterMethod() {
	 * System.out.println("afterMethod  - Module2"); }
	 * 
	 * @BeforeClass public void beforeClass() {
	 * System.out.println("beforeClass  - Module2"); }
	 */
  
  
}
