package week1.day2;

public class LearnSwitchStatement {

	public static void main(String[] args) {
		//int day = 4;
		
		String browser = "firefox";

		switch (browser) {
		case "chrome":
			System.out.println("chrome browser");
			break;
		case "edge":
			System.out.println("edge browser");
			break;
		case "firefox":
			System.out.println("firefox browser");
			break;
		
		}

		/*
		 * if(day == 1) { System.out.println("Monday"); }else if(day ==2) {
		 * System.out.println("Tuesday"); }else if(day == 3) {
		 * System.out.println("Wednesday"); } else if(day == 4) {
		 * System.out.println("Thursday"); } else if(day == 5) {
		 * System.out.println("Friday"); } else { System.out.println("weekend"); }
		 */

	}

}
