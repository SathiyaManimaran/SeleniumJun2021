package week1.day2;

public class LearnLooping {

	public static void main(String[] args) {
		int x = 15;
		
		do {
			
			System.out.println(x);
			
		}while(x < 10);
		
		/*
		 * while(x < 10) { System.out.println(x); x = x + 1; }
		 */

	}

}
