package week1.day1;

public class OwnCar {
		
	public static void main(String[] args) {
		Car myCar = new Car();
		myCar.driveCar();
		myCar.applyBrake();
		
		
		
	
	}

}
