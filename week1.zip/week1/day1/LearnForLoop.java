package week1.day1;

public class LearnForLoop {

	public static void main(String[] args) {

		// int i = 5;

		// ++i -> pre increment
		// i++ -> post increment
		// System.out.println(++i);

		// System.out.println(i);

		// initialize ; condition ; increment / decrement
		for (int i = 1; i <= 100; i++) {
			
			if(i % 2 == 1) {
				
				System.out.println(i);
			}
			
		}

	}

}
