package week1.assignments;

public class DoubtsClarification {

	public static void main(String[] args) {
		int[] values = new int[3];
		
		values[0] = 10;
		values[1] = 20;
		
		System.out.println(values[2]);

	}

}
