package week8.day1;

public class CreateRandomNumber {

	public static void main(String[] args) {
		//will create random number between 0 to 1
		System.out.println((int) (Math.random()* 999999));

	}

}
